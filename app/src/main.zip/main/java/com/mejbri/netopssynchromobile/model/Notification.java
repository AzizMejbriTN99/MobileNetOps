package com.mejbri.netopssynchromobile.model;

public class Notification {
    public Long   id;
    public String type;
    public String targetRole;
    public String targetUsername;
    public String message;
    public boolean read;
    public String createdAt;
}